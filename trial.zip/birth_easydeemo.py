import pickle

f = open('operators.pik','rb')
b = open('birthdays.pik','rb')
operators = pickle.load(f)
birthdays = pickle.load(b)

prompt = '请输入您的生日,按q退出:'
while True:
    birth = input(prompt)
    if birth =='q':
        break
    if birth in birthdays:
        print('您和{0}同一天生日哦！'.format(operators[birthdays.index(birth)]))
    else:
        print('看来没有和您同一天生日的干员呢..')
print('感谢您使用明日方舟干员生日查询器demo')

f.close()
b.close()
