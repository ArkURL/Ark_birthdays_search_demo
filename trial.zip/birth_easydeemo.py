import pickle

f = open('operators.pik','rb')
b = open('birthdays.pik','rb')
operators = pickle.load(f)
birthdays = pickle.load(b)
pos = 0
tag = 0

prompt = '请输入您的生日(格式为xxxx,如1224表示12月24日),按q退出:'
while True:
    birth = input(prompt)
    prompt = '请输入您的生日,按q退出:'
    if birth =='q':
        break
    if birth.isdigit() and len(birth) == 4:
        for each in birthdays:
            if each == birth:
                print('您和{0}同一天生日哦！'.format(operators[birthdays.index(each,pos)]))
                tag = 1
            if tag == 1:
                pos = birthdays.index(each,pos)+1
                tag = 0
        if birth not in birthdays:
            print('看来没有和您同一天生日的干员呢..')
        pos = 0
        tag = 0
    else:
        print('请输入有效的输入，如数字1224')
print('感谢您使用明日方舟干员生日查询器demo')

f.close()
b.close()
