import urllib.request
from bs4 import BeautifulSoup
import pickle

#简易版生日查询
#非常简易！甚至连对应的干员都找不到！
#所以只是一个简单的查找你和方舟干员有没有同一天生日的查询器
'''
已公开生日的干员的生日
'''

header = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.80 Safari/537.36 Edg/86.0.622.43'
url = 'http://prts.wiki/w/%E6%A1%A3%E6%A1%88%E4%BF%A1%E6%81%AF%E4%B8%80%E8%A7%88'

req = urllib.request.Request(url)
req.add_header('User-Agent',header)
response = urllib.request.urlopen(req).read()
html = response.decode('utf-8')

soup = BeautifulSoup(html,'lxml')

operators_list = []
birth_list = []
word = ''
for each in soup.findAll('td'):
    word = each.get('data-sort-value')
    if isinstance(word,str):
        if len(word) == 4:
            birth_list.append(word)
for each in soup.findAll('a'):
    opt = each.get('title')
    if isinstance(opt,str):
        operators_list.append(opt)
        if opt == '夜刀':
            break

operators_list.remove('W')
operators_list.remove('断罪者')
operators_list.remove('煌')
operators_list.remove('黑')
operators_list.remove('守林人')
operators_list.remove('狮蝎')
operators_list.remove('蛇屠箱')

operators_list.extend(['Thermal-EX','Castle-3','Lancet-2'])
#小车们的生日，由于不在prts的档案一览中可以查询，所以手动添加
birth_list.extend(['0215','1210','0512'])

with open('operators.pik','wb') as f:
    pickle.dump(operators_list,f)
with open('birthdays.pik','wb') as b:
    pickle.dump(birth_list,b)
